<?php

namespace spec\Artesaos\SEOTools;

use PhpSpec\ObjectBehavior;

class OpenGraphSpec extends ObjectBehavior
{
    public function it_is_initializable()
    {
        $this->shouldHaveType('Artesaos\SEOTools\OpenGraph');
    }
}

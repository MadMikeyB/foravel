<?php namespace DaveJamesMiller\Breadcrumbs;

class Exception extends \Exception {
}

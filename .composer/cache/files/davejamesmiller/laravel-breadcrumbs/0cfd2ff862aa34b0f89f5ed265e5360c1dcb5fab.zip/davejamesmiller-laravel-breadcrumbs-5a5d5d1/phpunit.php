<?php

// Load Composer packages
require __DIR__ . '/vendor/autoload.php';

// Load base class
require __DIR__ . '/tests/TestCase.php';

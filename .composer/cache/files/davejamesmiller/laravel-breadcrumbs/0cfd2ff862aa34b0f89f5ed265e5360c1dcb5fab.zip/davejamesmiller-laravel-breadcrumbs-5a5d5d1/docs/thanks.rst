################################################################################
 Thanks to
################################################################################

This package is largely based on the `Gretel <https://github.com/lassebunk/gretel>`_ plugin for Ruby on Rails, which I used for a while before discovering Laravel.

And of course it would be nothing without `Laravel <http://laravel.com/>`_ itself!

================================================================================
 Contributors
================================================================================

- Christian Thomas (`christian-thomas <https://github.com/christian-thomas>`_) -
  `#62 <https://github.com/davejamesmiller/laravel-breadcrumbs/issues/62#issuecomment-71724019>`_
- Miloš Levačić (`levacic <https://github.com/levacic>`_) -
  `#56 <https://github.com/davejamesmiller/laravel-breadcrumbs/pull/56>`_
- Ricky Wiens (`rickywiens <https://github.com/rickywiens>`_) -
  `#41 <https://github.com/davejamesmiller/laravel-breadcrumbs/pull/41>`_
- Boris Glumpler (`shabushabu <https://github.com/shabushabu>`_) -
  `#28 <https://github.com/davejamesmiller/laravel-breadcrumbs/pull/28>`_
- Andrej Badin (`Andreyco <https://github.com/Andreyco>`_) -
  `#24 <https://github.com/davejamesmiller/laravel-breadcrumbs/pull/24>`_
- Stef Horner (`tedslittlerobot <https://github.com/tedslittlerobot>`_) -
  `#11 <https://github.com/davejamesmiller/laravel-breadcrumbs/pull/11>`_

<?php namespace YAAP\Theme\Exceptions;

class ThemeException extends \Exception {}

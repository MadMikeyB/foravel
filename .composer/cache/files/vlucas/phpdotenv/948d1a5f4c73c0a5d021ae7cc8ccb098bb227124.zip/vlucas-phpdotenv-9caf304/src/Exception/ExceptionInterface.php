<?php

namespace Dotenv\Exception;

/**
 * This is the exception interface.
 */
interface ExceptionInterface
{
    //
}

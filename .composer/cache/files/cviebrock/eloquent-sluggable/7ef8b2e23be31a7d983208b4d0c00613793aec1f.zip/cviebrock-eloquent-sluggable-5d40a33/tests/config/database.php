<?php

/**
 * Test against in-memory SQLite database
 */

return [
  'driver' => 'sqlite',
  'database' => ':memory:',
  'prefix' => ''
];

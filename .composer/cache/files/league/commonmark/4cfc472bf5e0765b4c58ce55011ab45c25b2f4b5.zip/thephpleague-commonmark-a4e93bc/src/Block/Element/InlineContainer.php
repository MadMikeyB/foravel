<?php

namespace League\CommonMark\Block\Element;

interface InlineContainer
{
    public function getStringContent();
}
